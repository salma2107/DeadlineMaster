@echo off
cd /d "%~dp0"
java -cp ".;lib\mysql-connector-java.jar;dist\DeadlineMaster.jar" deadlineMaster.BackgroundReminder
pause