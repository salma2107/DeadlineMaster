package deadlineMaster;

import java.awt.AWTException;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.RenderingHints;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

public class GuiDM extends JFrame {
	private static final long serialVersionUID = 1L;
    static final Color BG_APP         = new Color(0xF1F5F9);
    static final Color BG_WHITE       = Color.WHITE;
    static final Color BLUE_PRIMARY   = new Color(0x3B82F6);
    static final Color BLUE_LIGHT     = new Color(0xEFF6FF);
    static final Color BLUE_BORDER    = new Color(0xBFDBFE);
    static final Color GREEN_PRIMARY  = new Color(0x10B981);
    static final Color GREEN_LIGHT    = new Color(0xF0FDF4);
    static final Color GREEN_BORDER   = new Color(0xBBF7D0);
    static final Color RED_PRIMARY    = new Color(0xEF4444);
    static final Color RED_LIGHT      = new Color(0xFFF1F2);
    static final Color RED_BORDER     = new Color(0xFECACA);
    static final Color YELLOW_PRIMARY = new Color(0xF59E0B);
    static final Color YELLOW_LIGHT   = new Color(0xFFFBEB);
    static final Color YELLOW_BORDER  = new Color(0xFDE68A);
    static final Color PURPLE_PRIMARY = new Color(0x8B5CF6);
    static final Color PURPLE_LIGHT   = new Color(0xF5F3FF);
    static final Color PURPLE_BORDER  = new Color(0xDDD6FE);
    static final Color TEXT_DARK      = new Color(0x1E293B);
    static final Color TEXT_MUTED     = new Color(0x64748B);
    static final Color BORDER_COLOR   = new Color(0xE2E8F0);
    static final Color SIDEBAR_SEL    = new Color(0xEFF6FF);

    static final Color BADGE_IP_BG    = new Color(0xE0F2FE);
    static final Color BADGE_IP_FG    = new Color(0x0284C7);
    static final Color BADGE_PEND_BG  = new Color(0xFEE2E2);
    static final Color BADGE_PEND_FG  = new Color(0xDC2626);
    static final Color BADGE_DONE_BG  = new Color(0xDCFCE7);
    static final Color BADGE_DONE_FG  = new Color(0x16A34A);
    static final Color BADGE_TERL_BG  = new Color(0xFFE4E6);
    static final Color BADGE_TERL_FG  = new Color(0x9F1239);

    static final Color[] MATKUL_COLORS = {
        new Color(0x3B82F6), new Color(0xEF4444), new Color(0x10B981),
        new Color(0xF59E0B), new Color(0x8B5CF6), new Color(0xEC4899)
    };

    private final int    userId;
    private final String username;
    private final TugasController controller = new TugasController();
    private Map<Integer, String> matkulMap   = new LinkedHashMap<>();
    private List<TugasController.Tugas> allTugas = new ArrayList<>();

    private String  activeFilter   = "Semua";
    private String  searchKeyword  = "";
    private int     filterMatkulId = 0;

    private JLabel   lblStatAktif, lblStatMendesak, lblStatSelesai, lblStatTerlewat;
    private DefaultTableModel tableModel;
    private JTable   table;
    private JLabel   lblSideSelMendesak, lblSideSelBelum, lblSideSelSelesai, lblSideSelTerlewat;
    private JLabel   lblBadgeMendesak, lblBadgeBelum, lblBadgeSelesai, lblBadgeTerlewat;
    private JComboBox<String> cmbMatkul;
    private JTextField txtSearch;

    private TrayIcon trayIcon;
    private javax.swing.Timer reminderTimer;

    private JLabel lblPomodoroTime;
    private javax.swing.Timer pomodoroTimer;
    private int pomodoroSeconds = 25 * 60;
    private boolean pomodoroFocus = true;
    private boolean pomodoroRunning = false;

    public GuiDM(int userId, String username) {
        super("DeadlineMaster v2.0  —  " + username);
        this.userId   = userId;
        this.username = username;

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(1120, 700);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(960, 600));
        getContentPane().setBackground(BG_APP);
        getContentPane().setLayout(new BorderLayout(0, 0));

        loadMatkul();
        buildUI();
        refreshData();
        setupSystemTray();
        setupReminderTimer();

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { hideToTray(); }
        });

        setVisible(true);
    }

    private void loadMatkul() {
        try { matkulMap = controller.dapatkanSemuaMatkul(); }
        catch (SQLException e) { showError("Gagal memuat data matkul: " + e.getMessage()); }
    }

    private void refreshData() {
        SwingWorker<Void, Void> w = new SwingWorker<>() {
            TugasController.Statistik stat;
            List<TugasController.Tugas> list;

            @Override protected Void doInBackground() throws Exception {
                stat = controller.hitungStatistikUser(userId);
                boolean mendesak = activeFilter.equals("Mendesak");
                String status = switch (activeFilter) {
                    case "Belum"    -> null;
                    case "Selesai"  -> "Done";
                    case "Terlewat" -> "Terlewat";
                    default         -> null;
                };
                list = controller.cariTugas(userId, status, searchKeyword, mendesak, filterMatkulId);
                if (activeFilter.equals("Belum")) {
                    list.removeIf(t -> t.status.equals("Done") || t.status.equals("Terlewat"));
                }
                return null;
            }

            @Override protected void done() {
                try {
                    get();
                    allTugas = list;
                    updateStatCards(stat);
                    updateSidebarBadges(stat);
                    populateTable(list);
                } catch (Exception ex) {
                    showError("Gagal memuat data: " + ex.getMessage());
                }
            }
        };
        w.execute();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(BG_APP);
        root.setBorder(new EmptyBorder(16, 16, 16, 16));
        getContentPane().add(root, BorderLayout.CENTER);

        root.add(buildHeader(),      BorderLayout.NORTH);
        root.add(buildCenter(),      BorderLayout.CENTER);
        root.add(buildActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new GridLayout(1, 4, 12, 0));
        p.setOpaque(false);
        p.setPreferredSize(new Dimension(0, 100));

        JPanel cardAktif = buildStatCard("TUGAS AKTIF", "📊", BLUE_LIGHT, BLUE_BORDER, BLUE_PRIMARY);
        lblStatAktif = (JLabel) cardAktif.getClientProperty("numLabel");

        JPanel cardMendesak = buildStatCard("MENDESAK", "⏰", YELLOW_LIGHT, YELLOW_BORDER, YELLOW_PRIMARY);
        lblStatMendesak = (JLabel) cardMendesak.getClientProperty("numLabel");

        JPanel cardSelesai = buildStatCard("SUDAH SELESAI", "✅", GREEN_LIGHT, GREEN_BORDER, GREEN_PRIMARY);
        lblStatSelesai = (JLabel) cardSelesai.getClientProperty("numLabel");

        JPanel cardTerlewat = buildStatCard("TERLEWAT", "⚠", RED_LIGHT, RED_BORDER, RED_PRIMARY);
        lblStatTerlewat = (JLabel) cardTerlewat.getClientProperty("numLabel");

        p.add(cardAktif);
        p.add(cardMendesak);
        p.add(cardSelesai);
        p.add(cardTerlewat);
        return p;
    }

    private JPanel buildStatCard(String title, String icon, Color bg, Color border, Color accent) {
        RoundedPanel card = new RoundedPanel(16, bg, border);
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(14, 18, 14, 18));

        JPanel inner = new JPanel();
        inner.setOpaque(false);
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));

        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        topRow.setOpaque(false);
        JLabel lblIcon = new JLabel(icon);
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblTitle.setForeground(TEXT_MUTED);
        topRow.add(lblIcon);
        topRow.add(lblTitle);

        JLabel lblNum = new JLabel("0");
        lblNum.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblNum.setForeground(accent);

        inner.add(topRow);
        inner.add(Box.createVerticalStrut(2));
        inner.add(lblNum);

        card.add(inner, BorderLayout.CENTER);
        card.putClientProperty("numLabel", lblNum);
        return card;
    }

    private JPanel buildCenter() {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setOpaque(false);
        p.add(buildSidebar(),    BorderLayout.WEST);
        p.add(buildMainRight(),  BorderLayout.CENTER);
        return p;
    }

    private JPanel buildMainRight() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.add(buildTablePanel(),   BorderLayout.CENTER);
        p.add(buildPomodoroPanel(), BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildSidebar() {
    	RoundedPanel side = new RoundedPanel(16, BG_WHITE, BORDER_COLOR);
        // GANTI KE BORDERLAYOUT UNTUK STRUKTUR UTAMA SIDEBAR
        side.setLayout(new BorderLayout(0, 10)); 
        side.setBorder(new EmptyBorder(20, 14, 20, 14));
        side.setPreferredSize(new Dimension(200, 0));

        // Buat panel atas untuk menampung Title, Search, dan ComboBox
        JPanel pnlTop = new JPanel();
        pnlTop.setLayout(new BoxLayout(pnlTop, BoxLayout.Y_AXIS));
        pnlTop.setOpaque(false);

        JLabel lblTitle = new JLabel("Quick Filters");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTitle.setForeground(TEXT_DARK);
        lblTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtSearch = new JTextField();
        txtSearch.setText("Cari Tugas...");
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        txtSearch.setForeground(TEXT_DARK);
        txtSearch.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
            new EmptyBorder(5, 10, 5, 10)
        ));
        txtSearch.putClientProperty("JTextField.placeholderText", "🔍 Cari tugas...");
        txtSearch.addKeyListener(new KeyAdapter() {
            @Override public void keyReleased(KeyEvent e) {
                searchKeyword = txtSearch.getText();
                refreshData();
            }
        });

        List<String> matkulNames = new ArrayList<>();
        matkulNames.add("Filter Matkul");
        matkulNames.addAll(matkulMap.values());
        cmbMatkul = new JComboBox<>(matkulNames.toArray(new String[0]));
        cmbMatkul.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbMatkul.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cmbMatkul.setBackground(BG_WHITE);
        cmbMatkul.addActionListener(e -> {
            int sel = cmbMatkul.getSelectedIndex();
            if (sel <= 0) { filterMatkulId = 0; }
            else {
                String name = (String) cmbMatkul.getSelectedItem();
                filterMatkulId = matkulMap.entrySet().stream()
                    .filter(en -> en.getValue().equals(name))
                    .map(Map.Entry::getKey).findFirst().orElse(0);
            }
            refreshData();
        });

        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_COLOR);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        pnlTop.add(lblTitle);
        pnlTop.add(Box.createVerticalStrut(12));
        pnlTop.add(txtSearch);
        pnlTop.add(Box.createVerticalStrut(8));
        pnlTop.add(cmbMatkul);
        pnlTop.add(Box.createVerticalStrut(10));
        pnlTop.add(sep);

        // KUNCI UTAMA: Gunakan GridLayout (4 baris, 1 kolom) agar item filter pasti sejajar rapi
        JPanel pnlCenter = new JPanel(new GridLayout(4, 1, 0, 6));
        pnlCenter.setOpaque(false);

        JPanel itemMendesak = buildSideItem("Mendesak Saja",  "0", false);
        JPanel itemBelum    = buildSideItem("Belum Selesai",  "0", false);
        JPanel itemSelesai  = buildSideItem("Selesai Saja",   "0", false);
        JPanel itemTerlewat = buildSideItem("Terlewat",       "0", false);

        lblSideSelMendesak = (JLabel) itemMendesak.getClientProperty("lblSel");
        lblSideSelBelum    = (JLabel) itemBelum.getClientProperty("lblSel");
        lblSideSelSelesai  = (JLabel) itemSelesai.getClientProperty("lblSel");
        lblSideSelTerlewat = (JLabel) itemTerlewat.getClientProperty("lblSel");
        lblBadgeMendesak   = (JLabel) itemMendesak.getClientProperty("badge");
        lblBadgeBelum      = (JLabel) itemBelum.getClientProperty("badge");
        lblBadgeSelesai    = (JLabel) itemSelesai.getClientProperty("badge");
        lblBadgeTerlewat   = (JLabel) itemTerlewat.getClientProperty("badge");

        for (JPanel item : new JPanel[]{itemMendesak, itemBelum, itemSelesai, itemTerlewat}) {
            item.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) {
                    setActiveFilter(
                        (String) item.getClientProperty("filter"),
                        (JLabel)  item.getClientProperty("lblSel")
                    );
                }
                @Override public void mouseEntered(MouseEvent e) { item.setBackground(SIDEBAR_SEL); }
                @Override public void mouseExited(MouseEvent e) {
                    boolean active = activeFilter.equals(item.getClientProperty("filter"));
                    item.setBackground(active ? SIDEBAR_SEL : BG_WHITE);
                }
            });
            pnlCenter.add(item); // Masukkan ke GridLayout
        }
        itemMendesak.putClientProperty("filter", "Mendesak");
        itemBelum.putClientProperty("filter",    "Belum");
        itemSelesai.putClientProperty("filter",  "Selesai");
        itemTerlewat.putClientProperty("filter", "Terlewat");

        // Bagian Bawah untuk Reset dan Logout
        JPanel pnlBottom = new JPanel();
        pnlBottom.setLayout(new BoxLayout(pnlBottom, BoxLayout.Y_AXIS));
        pnlBottom.setOpaque(false);

        JLabel lblReset = new JLabel("Tampilkan Semua");
        lblReset.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblReset.setForeground(BLUE_PRIMARY);
        lblReset.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblReset.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblReset.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                setActiveFilter("Semua", null);
                txtSearch.setText("");
                searchKeyword = "";
                cmbMatkul.setSelectedIndex(0);
                filterMatkulId = 0;
            }
        });

        JSeparator sepBottom = new JSeparator();
        sepBottom.setForeground(BORDER_COLOR);
        sepBottom.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        JPanel itemLogout = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        itemLogout.setOpaque(true);
        itemLogout.setBackground(BG_WHITE);
        itemLogout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        itemLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        itemLogout.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblLogoutIcon = new JLabel("🚪");
        lblLogoutIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        JLabel lblLogoutText = new JLabel("Keluar Akun");
        lblLogoutText.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblLogoutText.setForeground(RED_PRIMARY);
        itemLogout.add(lblLogoutIcon);
        itemLogout.add(lblLogoutText);
        itemLogout.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { doLogout(); }
            @Override public void mouseEntered(MouseEvent e) { itemLogout.setBackground(RED_LIGHT); }
            @Override public void mouseExited(MouseEvent e)  { itemLogout.setBackground(BG_WHITE); }
        });

        pnlBottom.add(lblReset);
        pnlBottom.add(Box.createVerticalStrut(10));
        pnlBottom.add(sepBottom);
        pnlBottom.add(Box.createVerticalStrut(6));
        pnlBottom.add(itemLogout);

        // Masukkan ketiga bagian besar ke posisi BorderLayout masing-masing
        side.add(pnlTop, BorderLayout.NORTH);
        side.add(pnlCenter, BorderLayout.CENTER);
        side.add(pnlBottom, BorderLayout.SOUTH);

        return side;
    }

    private JPanel buildSideItem(String label, String badgeNum, boolean selected) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(true);
        p.setBackground(selected ? SIDEBAR_SEL : BG_WHITE);
        p.setBorder(new EmptyBorder(6, 10, 6, 10)); // Sedikit dikurangi agar lebih ramping
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36)); // Kunci tinggi baris agar konsisten
        p.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel lblSel = new JLabel(label);
        lblSel.setFont(new Font("Segoe UI", selected ? Font.BOLD : Font.PLAIN, 13));
        lblSel.setForeground(selected ? BLUE_PRIMARY : TEXT_DARK);

        JLabel badge = new JLabel(badgeNum);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setForeground(TEXT_MUTED);
        badge.setHorizontalAlignment(SwingConstants.CENTER);
        badge.setPreferredSize(new Dimension(32, 22)); // Memperlebar sedikit space angka kotak
        badge.setOpaque(true);
        badge.setBackground(BORDER_COLOR);
        badge.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 4));

        p.add(lblSel,  BorderLayout.WEST);
        p.add(badge,   BorderLayout.EAST);
        p.putClientProperty("lblSel", lblSel);
        p.putClientProperty("badge",  badge);
        return p;
    }

    private void setActiveFilter(String filter, JLabel activeLbl) {
        activeFilter = filter;
        for (JLabel lbl : new JLabel[]{lblSideSelMendesak, lblSideSelBelum, lblSideSelSelesai, lblSideSelTerlewat}) {
            lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            lbl.setForeground(TEXT_DARK);
        }
        if (activeLbl != null) {
            activeLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
            activeLbl.setForeground(BLUE_PRIMARY);
        }
        refreshData();
    }

    private JPanel buildTablePanel() {
        RoundedPanel panel = new RoundedPanel(16, BG_WHITE, BORDER_COLOR);
        panel.setLayout(new BorderLayout(0, 10));
        panel.setBorder(new EmptyBorder(18, 18, 18, 18));

        JLabel lblJudul = new JLabel("Daftar Tugas Anda");
        lblJudul.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblJudul.setForeground(TEXT_DARK);

        String[] cols = {"Matkul", "Tugas", "Due", "Prioritas", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(42);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(0xF1F5F9));
        table.setBackground(BG_WHITE);
        table.setSelectionBackground(new Color(0xEFF6FF));
        table.setSelectionForeground(TEXT_DARK);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFocusable(false);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setBackground(new Color(0xF8FAFC));
        header.setForeground(TEXT_MUTED);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        header.setReorderingAllowed(false);

        int[] widths = {140, 0, 100, 90, 110};
        for (int i = 0; i < widths.length; i++) {
            TableColumn col = table.getColumnModel().getColumn(i);
            if (widths[i] > 0) col.setPreferredWidth(widths[i]);
        }
        table.getColumnModel().getColumn(0).setCellRenderer(new MatkulCellRenderer());
        table.getColumnModel().getColumn(4).setCellRenderer(new StatusBadgeRenderer());

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(BG_WHITE);
        scroll.setBackground(BG_WHITE);

        panel.add(lblJudul, BorderLayout.NORTH);
        panel.add(scroll,   BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildPomodoroPanel() {
        RoundedPanel panel = new RoundedPanel(16, PURPLE_LIGHT, PURPLE_BORDER);
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        panel.setBorder(new EmptyBorder(10, 18, 10, 18));
        panel.setPreferredSize(new Dimension(0, 56));

        JLabel lblIcon = new JLabel("🍅");
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));

        JLabel lblLabel = new JLabel(" Pomodoro:");
        lblLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblLabel.setForeground(PURPLE_PRIMARY);
        lblLabel.setToolTipText(
        	    "<html><b>Teknik Pomodoro:</b><br>" +
        	    "Metode manajemen waktu: 25 menit fokus penuh untuk mengerjakan tugas,<br>" +
        	    "lalu diselingi dengan 5 menit istirahat agar otak tetap segar.</html>"
        	);

        lblPomodoroTime = new JLabel("25:00");
        lblPomodoroTime.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblPomodoroTime.setForeground(PURPLE_PRIMARY);
        lblPomodoroTime.setBorder(new EmptyBorder(0, 10, 0, 10));

        JLabel lblMode = new JLabel("FOKUS");
        lblMode.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblMode.setForeground(TEXT_MUTED);

        pomodoroTimer = new javax.swing.Timer(1000, e -> tickPomodoro(lblMode));

        RoundBtn btnStart = new RoundBtn("Mulai", PURPLE_PRIMARY, new Color(0x7C3AED));
        btnStart.setPreferredSize(new Dimension(90, 34));
        RoundBtn btnReset = new RoundBtn("Reset", new Color(0xE2E8F0), BORDER_COLOR);
        btnReset.setForeground(TEXT_DARK);
        btnReset.setPreferredSize(new Dimension(80, 34));

        btnStart.addActionListener(e -> {
            if (!pomodoroRunning) {
                pomodoroRunning = true;
                pomodoroTimer.start();
                btnStart.setText("⏸ Jeda");
            } else {
                pomodoroRunning = false;
                pomodoroTimer.stop();
                btnStart.setText("▶ Lanjut");
            }
        });

        btnReset.addActionListener(e -> {
            pomodoroTimer.stop();
            pomodoroRunning = false;
            pomodoroFocus = true;
            pomodoroSeconds = 25 * 60;
            updatePomodoroLabel();
            lblMode.setText("FOKUS");
            lblMode.setForeground(TEXT_MUTED);
            btnStart.setText("▶ Mulai");
        });

        panel.add(lblIcon);
        panel.add(lblLabel);
        panel.add(Box.createHorizontalStrut(6));
        panel.add(lblPomodoroTime);
        panel.add(lblMode);
        panel.add(Box.createHorizontalGlue());
        panel.add(btnStart);
        panel.add(Box.createHorizontalStrut(8));
        panel.add(btnReset);

        return panel;
    }

    private void tickPomodoro(JLabel lblMode) {
        if (pomodoroSeconds > 0) {
            pomodoroSeconds--;
            updatePomodoroLabel();
        } else {
            pomodoroTimer.stop();
            pomodoroRunning = false;
            if (pomodoroFocus) {
                pomodoroFocus = false;
                pomodoroSeconds = 5 * 60;
                lblMode.setText("ISTIRAHAT");
                lblMode.setForeground(GREEN_PRIMARY);
                JOptionPane.showMessageDialog(this,
                    "Waktu fokus selesai! Saatnya istirahat 5 menit 🎉",
                    "Pomodoro", JOptionPane.INFORMATION_MESSAGE);
            } else {
                pomodoroFocus = true;
                pomodoroSeconds = 25 * 60;
                lblMode.setText("FOKUS");
                lblMode.setForeground(TEXT_MUTED);
                JOptionPane.showMessageDialog(this,
                    "Istirahat selesai! Kembali fokus 25 menit 💪",
                    "Pomodoro", JOptionPane.INFORMATION_MESSAGE);
            }
            updatePomodoroLabel();
        }
    }

    private void updatePomodoroLabel() {
        int m = pomodoroSeconds / 60;
        int s = pomodoroSeconds % 60;
        lblPomodoroTime.setText(String.format("%02d:%02d", m, s));
    }

    private void populateTable(List<TugasController.Tugas> list) {
        tableModel.setRowCount(0);
        for (TugasController.Tugas t : list) {
            tableModel.addRow(new Object[]{
                t.namaMatkul, t.namaTugas, t.deadline, t.prioritas, t.status
            });
        }
    }

    private JPanel buildActionPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.setPreferredSize(new Dimension(0, 58));

        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        p.setBorder(new EmptyBorder(0, 4, 0, 4));

        RoundBtn btnBaru    = new RoundBtn("Baru",      new Color(0x10B981), new Color(0x059669));
        RoundBtn btnSelesai = new RoundBtn("Selesai",   new Color(0x3B82F6), new Color(0x2563EB));
        RoundBtn btnUbah    = new RoundBtn("Ubah",      new Color(0xF59E0B), new Color(0xD97706));
        RoundBtn btnHapus   = new RoundBtn("Hapus",    new Color(0xEF4444), new Color(0xDC2626));
        RoundBtn btnEkspor  = new RoundBtn("Ekspor CSV", new Color(0x94A3B8), new Color(0x64748B));
        RoundBtn btnKalender = new RoundBtn("Kalender", new Color(0x94A3B8), new Color(0x64748B));

        btnBaru.addActionListener    (e -> showDialogTambah());
        btnSelesai.addActionListener (e -> markSelectedDone());
        btnUbah.addActionListener    (e -> showDialogUbah());
        btnHapus.addActionListener   (e -> confirmHapus());
        btnEkspor.addActionListener  (e -> eksporCSV());
        btnKalender.addActionListener(e -> showKalender());

        p.add(btnBaru);    p.add(Box.createHorizontalStrut(8));
        p.add(btnSelesai); p.add(Box.createHorizontalStrut(8));
        p.add(btnUbah);    p.add(Box.createHorizontalStrut(8));
        p.add(btnHapus);
        p.add(Box.createHorizontalGlue());
        p.add(btnEkspor);  p.add(Box.createHorizontalStrut(8));
        p.add(btnKalender);

        outer.add(p, BorderLayout.CENTER);
        return outer;
    }

    private void updateStatCards(TugasController.Statistik stat) {
        lblStatAktif.setText(String.valueOf(stat.aktif));
        lblStatMendesak.setText(String.valueOf(stat.mendesak));
        lblStatSelesai.setText(String.valueOf(stat.selesai));
        lblStatTerlewat.setText(String.valueOf(stat.terlewat));
    }

    private void updateSidebarBadges(TugasController.Statistik stat) {
        lblBadgeMendesak.setText(String.valueOf(stat.mendesak));
        lblBadgeBelum.setText(String.valueOf(stat.aktif));
        lblBadgeSelesai.setText(String.valueOf(stat.selesai));
        lblBadgeTerlewat.setText(String.valueOf(stat.terlewat));
    }

    private JDatePickerImpl createDatePicker() {
        UtilDateModel model = new UtilDateModel();
        java.util.Calendar cal = java.util.Calendar.getInstance();
        model.setDate(cal.get(java.util.Calendar.YEAR),
                      cal.get(java.util.Calendar.MONTH),
                      cal.get(java.util.Calendar.DAY_OF_MONTH));
        model.setSelected(true);
        java.util.Properties p = new java.util.Properties();
        p.put("text.today",  "Hari Ini");
        p.put("text.month",  "Bulan");
        p.put("text.year",   "Tahun");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        return new JDatePickerImpl(datePanel, new DateLabelFormatter());
    }

    private String getDateFromPicker(JDatePickerImpl picker) {
        java.util.Date selected = (java.util.Date) picker.getModel().getValue();
        if (selected == null) return LocalDate.now().toString();
        return new java.text.SimpleDateFormat("yyyy-MM-dd").format(selected);
    }

    private static class DateLabelFormatter extends JFormattedTextField.AbstractFormatter {
    	private static final long serialVersionUID = 1L;
        private final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
        @Override public Object stringToValue(String text) throws java.text.ParseException {
            return sdf.parse(text);
        }
        @Override public String valueToString(Object value) {
            if (value != null) {
                java.util.Calendar cal = (java.util.Calendar) value;
                return sdf.format(cal.getTime());
            }
            return "";
        }
    }

    private void showDialogTambah() {
        JDialog dlg = createDialog("Tambah Tugas Baru", 440, 400);

        JComboBox<String> cmbM   = createMatkulCombo();
        JTextField        tfNama = createDlgField();
        JDatePickerImpl   datePicker = createDatePicker();
        JComboBox<String> cmbPri = new JComboBox<>(new String[]{"Tinggi","Sedang","Rendah"});
        cmbPri.setSelectedIndex(1);

        datePicker.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        JPanel form = buildFormPanel(
            new String[]{"Mata Kuliah:", "Nama Tugas:", "Deadline:", "Prioritas:"},
            new JComponent[]{cmbM, tfNama, datePicker, cmbPri}
        );

        RoundBtn btnSave = new RoundBtn("Simpan", new Color(0x10B981), new Color(0x059669));
        btnSave.setPreferredSize(new Dimension(120, 38));
        btnSave.addActionListener(e -> {
            String mName = (String) cmbM.getSelectedItem();
            String nama  = tfNama.getText().trim();
            String dl    = getDateFromPicker(datePicker);
            String pri   = (String) cmbPri.getSelectedItem();
            if (mName == null || nama.isEmpty()) {
                showError("Harap lengkapi semua field."); return;
            }
            try {
                int mid = controller.getIdMatkul(mName);
                controller.tambahTugas(userId, mid, nama, dl, pri);
                dlg.dispose();
                refreshData();
            } catch (SQLException ex) { showError("Gagal menyimpan: " + ex.getMessage()); }
        });

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);
        btnPanel.add(btnSave);
        dlg.getContentPane().add(form,     BorderLayout.CENTER);
        dlg.getContentPane().add(btnPanel, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void showDialogUbah() {
        int row = table.getSelectedRow();
        if (row < 0) { showError("Pilih tugas yang ingin diubah."); return; }
        TugasController.Tugas t = allTugas.get(row);

        JDialog dlg = createDialog("Ubah Tugas", 440, 440);

        JComboBox<String> cmbM   = createMatkulCombo();
        cmbM.setSelectedItem(t.namaMatkul);
        JTextField tfNama = createDlgField(); tfNama.setText(t.namaTugas);

        JDatePickerImpl datePicker = createDatePicker();
        try {
            LocalDate ld = LocalDate.parse(t.deadline, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            UtilDateModel dm = (UtilDateModel) datePicker.getModel();
            dm.setDate(ld.getYear(), ld.getMonthValue() - 1, ld.getDayOfMonth());
            dm.setSelected(true);
        } catch (Exception ignored) {}

        JComboBox<String> cmbPri  = new JComboBox<>(new String[]{"Tinggi","Sedang","Rendah"});
        cmbPri.setSelectedItem(t.prioritas);
        JComboBox<String> cmbStat = new JComboBox<>(new String[]{"Pending","In Progress","Done","Terlewat"});
        cmbStat.setSelectedItem(t.status);

        JPanel form = buildFormPanel(
            new String[]{"Mata Kuliah:", "Nama Tugas:", "Deadline:", "Prioritas:", "Status:"},
            new JComponent[]{cmbM, tfNama, datePicker, cmbPri, cmbStat}
        );

        RoundBtn btnSave = new RoundBtn("Simpan", new Color(0xF59E0B), new Color(0xD97706));
        btnSave.setPreferredSize(new Dimension(120, 38));
        btnSave.addActionListener(e -> {
            try {
                int mid = controller.getIdMatkul((String) cmbM.getSelectedItem());
                controller.updateTugas(t.idTugas, mid, tfNama.getText().trim(),
                    getDateFromPicker(datePicker),
                    (String) cmbPri.getSelectedItem(),
                    (String) cmbStat.getSelectedItem());
                dlg.dispose();
                refreshData();
            } catch (SQLException ex) { showError("Gagal memperbarui: " + ex.getMessage()); }
        });

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setOpaque(false);
        btnPanel.add(btnSave);
        dlg.getContentPane().add(form,     BorderLayout.CENTER);
        dlg.getContentPane().add(btnPanel, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void markSelectedDone() {
        int row = table.getSelectedRow();
        if (row < 0) { showError("Pilih tugas yang ingin ditandai selesai."); return; }
        TugasController.Tugas t = allTugas.get(row);
        try {
            controller.ubahStatusTugas(t.idTugas, "Done");
            refreshData();
        } catch (SQLException ex) { showError("Gagal: " + ex.getMessage()); }
    }

    private void confirmHapus() {
        int row = table.getSelectedRow();
        if (row < 0) { showError("Pilih tugas yang ingin dihapus."); return; }
        TugasController.Tugas t = allTugas.get(row);
        int confirm = JOptionPane.showConfirmDialog(this,
            "Yakin ingin menghapus tugas \"" + t.namaTugas + "\"?",
            "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                controller.hapusTugas(t.idTugas);
                refreshData();
            } catch (SQLException ex) { showError("Gagal menghapus: " + ex.getMessage()); }
        }
    }

    private void eksporCSV() {
        // 1. Pastikan dulu datanya tidak kosong di tabel aplikasi
        if (allTugas == null || allTugas.isEmpty()) {
            showError("Tidak ada data tugas yang bisa diekspor.");
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("tugas_" + username + ".csv"));
        int result = chooser.showSaveDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) return;

        // Gunakan BufferedWriter dan bersihkan (flush) memori agar tulisan tidak nyangkut
        try (FileWriter fw = new FileWriter(chooser.getSelectedFile());
             java.io.BufferedWriter bw = new java.io.BufferedWriter(fw)) {
            
            // Tulis Judul Kolom
            bw.write("No,Matkul,Nama Tugas,Deadline,Prioritas,Status");
            bw.newLine();
            
            // Tulis Baris Data Tugas
            int no = 1;
            for (TugasController.Tugas t : allTugas) {
                String baris = no++ + ",\"" 
                    + t.namaMatkul.replace("\"", "\"\"") + "\",\"" 
                    + t.namaTugas.replace("\"", "\"\"") + "\","
                    + t.deadline + "," 
                    + t.prioritas + "," 
                    + t.status;
                bw.write(baris);
                bw.newLine();
            }
            
            bw.flush(); // Paksa Java menuangkan semua teks dari memori ke dalam file .csv
            
            JOptionPane.showMessageDialog(this,
                "Berhasil diekspor ke:\n" + chooser.getSelectedFile().getAbsolutePath(),
                "Ekspor Berhasil", JOptionPane.INFORMATION_MESSAGE);
                
        } catch (IOException ex) {
            showError("Gagal ekspor file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void showKalender() {
        JDialog dlg = createDialog("Kalender Deadline", 520, 420);
        dlg.getContentPane().setLayout(new BorderLayout(10, 10));

        LocalDate today = LocalDate.now();
        final int[] curYear  = {today.getYear()};
        final int[] curMonth = {today.getMonthValue()};

        JLabel lblMonth = new JLabel("", SwingConstants.CENTER);
        lblMonth.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblMonth.setForeground(TEXT_DARK);

        JPanel calGrid = new JPanel(new GridLayout(7, 7, 4, 4));
        calGrid.setOpaque(false);
        calGrid.setBorder(new EmptyBorder(8, 12, 8, 12));

        Runnable renderCal = () -> {
            calGrid.removeAll();
            String[] days = {"Min","Sen","Sel","Rab","Kam","Jum","Sab"};
            for (String d : days) {
                JLabel h = new JLabel(d, SwingConstants.CENTER);
                h.setFont(new Font("Segoe UI", Font.BOLD, 11));
                h.setForeground(TEXT_MUTED);
                calGrid.add(h);
            }
            LocalDate first = LocalDate.of(curYear[0], curMonth[0], 1);
            int startDow   = first.getDayOfWeek().getValue() % 7;
            int daysInMon  = first.lengthOfMonth();
            for (int i = 0; i < startDow; i++) calGrid.add(new JLabel(""));

            Set<String> deadlines = new HashSet<>();
            for (TugasController.Tugas t : allTugas) deadlines.add(t.deadline);

            for (int day = 1; day <= daysInMon; day++) {
                String dateStr = String.format("%d-%02d-%02d", curYear[0], curMonth[0], day);
                JLabel lbl = new JLabel(String.valueOf(day), SwingConstants.CENTER) {
                    @Override protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        boolean hasTask = deadlines.contains(dateStr);
                        boolean isToday = dateStr.equals(today.toString());
                        if (isToday) {
                            g2.setColor(BLUE_PRIMARY);
                            g2.fillOval(2, 2, getWidth()-4, getHeight()-4);
                            g2.setColor(Color.WHITE);
                        } else if (hasTask) {
                            g2.setColor(new Color(0xFEE2E2));
                            g2.fillOval(2, 2, getWidth()-4, getHeight()-4);
                            g2.setColor(RED_PRIMARY);
                        } else {
                            g2.setColor(TEXT_DARK);
                        }
                        g2.setFont(getFont());
                        FontMetrics fm = g2.getFontMetrics();
                        g2.drawString(getText(),
                            (getWidth() - fm.stringWidth(getText())) / 2,
                            (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                        g2.dispose();
                    }
                };
                lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                calGrid.add(lbl);
            }
            String[] monthNames = {"","Januari","Februari","Maret","April","Mei","Juni",
                "Juli","Agustus","September","Oktober","November","Desember"};
            lblMonth.setText(monthNames[curMonth[0]] + " " + curYear[0]);
            calGrid.revalidate(); calGrid.repaint();
        };

        RoundBtn btnPrev = new RoundBtn("<", new Color(0xE2E8F0), BORDER_COLOR);
        btnPrev.setForeground(TEXT_DARK);
        btnPrev.setPreferredSize(new Dimension(40, 32));
        btnPrev.addActionListener(e -> { curMonth[0]--; if (curMonth[0]<1){curMonth[0]=12;curYear[0]--;} renderCal.run(); });

        RoundBtn btnNext = new RoundBtn(">", new Color(0xE2E8F0), BORDER_COLOR);
        btnNext.setForeground(TEXT_DARK);
        btnNext.setPreferredSize(new Dimension(40, 32));
        btnNext.addActionListener(e -> { curMonth[0]++; if (curMonth[0]>12){curMonth[0]=1;curYear[0]++;} renderCal.run(); });

        JPanel navPanel = new JPanel(new BorderLayout());
        navPanel.setOpaque(false);
        navPanel.setBorder(new EmptyBorder(12, 12, 0, 12));
        navPanel.add(btnPrev, BorderLayout.WEST);
        navPanel.add(lblMonth, BorderLayout.CENTER);
        navPanel.add(btnNext, BorderLayout.EAST);

        JLabel legend = new JLabel("  🔵 Hari ini   🔴 Ada deadline");
        legend.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        legend.setForeground(TEXT_MUTED);
        legend.setBorder(new EmptyBorder(0, 12, 10, 12));

        dlg.getContentPane().add(navPanel,  BorderLayout.NORTH);
        dlg.getContentPane().add(calGrid,   BorderLayout.CENTER);
        dlg.getContentPane().add(legend,    BorderLayout.SOUTH);
        renderCal.run();
        dlg.setVisible(true);
    }

    private void setupSystemTray() {
        if (!SystemTray.isSupported()) return;
        SystemTray tray = SystemTray.getSystemTray();
        Image img = createTrayImage();
        PopupMenu popup = new PopupMenu();
        MenuItem itemBuka = new MenuItem("Buka Aplikasi");
        itemBuka.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            setVisible(true); setExtendedState(JFrame.NORMAL); toFront();
        }));
        MenuItem itemKeluar = new MenuItem("Keluar Total");
        itemKeluar.addActionListener(e -> {
            if (reminderTimer != null) reminderTimer.stop();
            tray.remove(trayIcon);
            System.exit(0);
        });
        popup.add(itemBuka);
        popup.addSeparator();
        popup.add(itemKeluar);
        trayIcon = new TrayIcon(img, "DeadlineMaster v2.0", popup);
        trayIcon.setImageAutoSize(true);
        trayIcon.addActionListener(e -> SwingUtilities.invokeLater(() -> {
            setVisible(true); setExtendedState(JFrame.NORMAL); toFront();
        }));
        try { tray.add(trayIcon); } catch (AWTException ex) { ex.printStackTrace(); }
    }

    private Image createTrayImage() {
        java.awt.image.BufferedImage img =
            new java.awt.image.BufferedImage(16, 16, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(BLUE_PRIMARY);
        g2.fillRoundRect(0, 0, 16, 16, 4, 4);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
        g2.drawString("D", 4, 12);
        g2.dispose();
        return img;
    }

    private void hideToTray() {
        if (trayIcon != null) {
            setVisible(false);
            trayIcon.displayMessage("DeadlineMaster v2.0",
                "Aplikasi disembunyikan. Kamu tetap akan menerima pengingat tugas.",
                TrayIcon.MessageType.INFO);
        } else {
            dispose(); System.exit(0);
        }
    }

    private void setupReminderTimer() {
        reminderTimer = new javax.swing.Timer(60 * 60 * 1000, e -> jalankanPengecekanPengingat());
        reminderTimer.setInitialDelay(5000);
        reminderTimer.start();
    }

    private void jalankanPengecekanPengingat() {
        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override protected Integer doInBackground() throws Exception {
                LocalDate today = LocalDate.now();
                List<TugasController.Tugas> semuaTugas = controller.dapatkanTugasUser(userId);
                int jumlah = 0;
                for (TugasController.Tugas t : semuaTugas) {
                    if (t.status.equals("Done") || t.status.equals("Terlewat")) continue;
                    try {
                        LocalDate dl = LocalDate.parse(t.deadline);
                        long sisa = java.time.temporal.ChronoUnit.DAYS.between(today, dl);
                        if (sisa >= 0 && sisa <= 2) jumlah++;
                    } catch (Exception ignored) {}
                }
                return jumlah;
            }
            @Override protected void done() {
                try {
                    int jumlah = get();
                    if (jumlah > 0 && trayIcon != null) {
                        trayIcon.displayMessage("Pengingat Tugas!",
                            "Ada " + jumlah + " tugas mendesak yang belum selesai. Yuk dikerjakan!",
                            TrayIcon.MessageType.WARNING);
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    private void doLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Apakah Anda ingin keluar?", "Konfirmasi Logout",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            if (reminderTimer != null) reminderTimer.stop();
            if (pomodoroTimer != null) pomodoroTimer.stop();
            if (trayIcon != null) SystemTray.getSystemTray().remove(trayIcon);
            this.dispose();
            new GuiLogin();
        }
    }

    class MatkulCellRenderer extends DefaultTableCellRenderer {
    	private static final long serialVersionUID = 1L;
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel lbl = (JLabel) super.getTableCellRendererComponent(
                table, value, isSelected, hasFocus, row, column);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
            lbl.setBorder(new EmptyBorder(0, 12, 0, 0));
            if (!isSelected) {
                String name = value == null ? "" : value.toString();
                int hash = Math.abs(name.hashCode()) % MATKUL_COLORS.length;
                lbl.setForeground(MATKUL_COLORS[hash]);
                lbl.setBackground(BG_WHITE);
            }
            return lbl;
        }
    }

    class StatusBadgeRenderer extends JPanel implements TableCellRenderer {
    	private static final long serialVersionUID = 1L;
        private final JLabel lbl = new JLabel("", SwingConstants.CENTER);
        private Color bgBadge = BADGE_IP_BG;

        StatusBadgeRenderer() {
            setLayout(new GridBagLayout());
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
            lbl.setOpaque(false);
            add(lbl);
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int col) {
            String status = value == null ? "" : value.toString();
            switch (status) {
                case "In Progress" -> { bgBadge = BADGE_IP_BG;   lbl.setForeground(BADGE_IP_FG);   }
                case "Pending"     -> { bgBadge = BADGE_PEND_BG; lbl.setForeground(BADGE_PEND_FG); }
                case "Done"        -> { bgBadge = BADGE_DONE_BG; lbl.setForeground(BADGE_DONE_FG); }
                case "Terlewat"    -> { bgBadge = BADGE_TERL_BG; lbl.setForeground(BADGE_TERL_FG); }
                default            -> { bgBadge = BORDER_COLOR;  lbl.setForeground(TEXT_MUTED);    }
            }
            lbl.setText(status);
            setBackground(isSelected ? new Color(0xEFF6FF) : BG_WHITE);
            return this;
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            FontMetrics fm = g2.getFontMetrics(lbl.getFont());
            int tw = fm.stringWidth(lbl.getText());
            int bw = tw + 24, bh = 24;
            int bx = (getWidth()  - bw) / 2;
            int by = (getHeight() - bh) / 2;
            g2.setColor(bgBadge);
            g2.fillRoundRect(bx, by, bw, bh, bh, bh);
            g2.dispose();
        }
    }

    private JDialog createDialog(String title, int w, int h) {
        JDialog dlg = new JDialog(this, title, true);
        dlg.setSize(w, h);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);
        dlg.getContentPane().setBackground(BG_APP);
        dlg.getContentPane().setLayout(new BorderLayout(10, 10));
        ((JPanel) dlg.getContentPane()).setBorder(new EmptyBorder(20, 20, 20, 20));
        return dlg;
    }

    private JPanel buildFormPanel(String[] labels, JComponent[] fields) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 4, 6, 4);
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lbl.setForeground(TEXT_DARK);
            p.add(lbl, gbc);
            gbc.gridx = 1; gbc.weightx = 1.0;
            fields[i].setFont(new Font("Segoe UI", Font.PLAIN, 12));
            p.add(fields[i], gbc);
        }
        return p;
    }

    private JTextField createDlgField() {
        JTextField tf = new JTextField();
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
            new EmptyBorder(6, 10, 6, 10)
        ));
        tf.setBackground(BG_WHITE);
        return tf;
    }

    private JComboBox<String> createMatkulCombo() {
        JComboBox<String> cmb = new JComboBox<>(matkulMap.values().toArray(new String[0]));
        cmb.setBackground(BG_WHITE);
        return cmb;
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Perhatian", JOptionPane.ERROR_MESSAGE);
    }

    static class RoundedPanel extends JPanel {
    	private static final long serialVersionUID = 1L;
        private final int radius;
        private final Color bg, borderColor;

        RoundedPanel(int radius, Color bg, Color border) {
            this.radius = radius; this.bg = bg; this.borderColor = border;
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 10));
            g2.fill(new RoundRectangle2D.Float(2, 4, getWidth()-4, getHeight()-2, radius*2, radius*2));
            g2.setColor(bg);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-2, radius*2, radius*2));
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.2f));
            g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth()-2, getHeight()-3, radius*2, radius*2));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    static class RoundBtn extends JButton {
    	private static final long serialVersionUID = 1L;
        private final Color bgNormal, bgHover;
        private Color fgColor = Color.WHITE;
        private boolean hovered = false;

        RoundBtn(String text, Color bgNormal, Color bgHover) {
            super(text);
            this.bgNormal = bgNormal; this.bgHover = bgHover;
            setFont(new Font("Segoe UI", Font.BOLD, 12));
            setForeground(Color.WHITE);
            setFocusPainted(false); setBorderPainted(false);
            setContentAreaFilled(false); setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(110, 40));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hovered = true;  repaint(); }
                @Override public void mouseExited (MouseEvent e) { hovered = false; repaint(); }
            });
        }

        public void setForeground(Color c) { this.fgColor = c; }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(hovered ? bgHover : bgNormal);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
            g2.setFont(getFont());
            g2.setColor(fgColor == null ? Color.WHITE : fgColor);
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth()  - fm.stringWidth(getText())) / 2;
            int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(getText(), x, y);
            g2.dispose();
        }
    }
}