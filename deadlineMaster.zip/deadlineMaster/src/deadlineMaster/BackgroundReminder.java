package deadlineMaster;

import java.awt.*;
import java.sql.*;
import java.util.List;

public class BackgroundReminder {

    public static void main(String[] args) {
        if (!SystemTray.isSupported()) {
            System.out.println("[BackgroundReminder] System Tray tidak didukung di OS ini.");
            return;
        }

        List<TugasController.Tugas> tugasH1 = null;
        try {
            TugasController ctrl = new TugasController();
            tugasH1 = ctrl.dapatkanSemuaTugasMenudesak();
        } catch (SQLException e) {
            System.err.println("[BackgroundReminder] Gagal koneksi database: " + e.getMessage());
            return;
        }

        if (tugasH1 == null || tugasH1.isEmpty()) {
            System.out.println("[BackgroundReminder] Tidak ada tugas yang mendekati deadline hari ini.");
            return;
        }

        StringBuilder pesanSb = new StringBuilder();
        int count = tugasH1.size();
        for (int i = 0; i < Math.min(3, count); i++) {
            TugasController.Tugas t = tugasH1.get(i);
            pesanSb.append("• ").append(t.namaTugas)
                   .append(" (").append(t.namaMatkul).append(")\n");
        }
        if (count > 3) pesanSb.append("...dan ").append(count - 3).append(" tugas lainnya.");

        String judul = "⚠ Pengingat DeadlineMaster — Deadline Besok!";
        String pesan = "Ada " + count + " tugas jatuh tempo besok:\n" + pesanSb.toString().trim();

        tampilkanNotifikasi(judul, pesan);
    }

    private static void tampilkanNotifikasi(String judul, String pesan) {
        try {
            SystemTray tray = SystemTray.getSystemTray();

            java.awt.image.BufferedImage img =
                new java.awt.image.BufferedImage(16, 16, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = img.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0xEF4444));
            g2.fillRoundRect(0, 0, 16, 16, 4, 4);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
            g2.drawString("!", 5, 12);
            g2.dispose();

            TrayIcon icon = new TrayIcon(img, "DeadlineMaster Reminder");
            icon.setImageAutoSize(true);
            tray.add(icon);

            icon.displayMessage(judul, pesan, TrayIcon.MessageType.WARNING);

            try { Thread.sleep(8000); } catch (InterruptedException ignored) {}

            tray.remove(icon);
            System.out.println("[BackgroundReminder] Notifikasi berhasil ditampilkan.");

        } catch (AWTException e) {
            System.err.println("[BackgroundReminder] Gagal menampilkan notifikasi: " + e.getMessage());
        }
    }
}