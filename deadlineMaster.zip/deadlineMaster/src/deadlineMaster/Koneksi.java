package deadlineMaster;

import java.sql.*;

public class Koneksi {

    private static final String HOST     = "localhost";
    private static final int    PORT     = 3306;
    private static final String DB_NAME  = "db_deadline_master";
    private static final String USER     = "root";
    private static final String PASSWORD = "";

    private static final String URL_WITH_DB = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME
            + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Jakarta";

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(URL_WITH_DB, USER, PASSWORD);
        ensureTablesExist(conn);
        return conn;
    }

    private static void ensureTablesExist(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement()) {
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS tabel_users (" +
                "  id_user    INT          AUTO_INCREMENT PRIMARY KEY, " +
                "  username   VARCHAR(50)  NOT NULL UNIQUE, " +
                "  password   VARCHAR(255) NOT NULL, " +
                "  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS tabel_matkul (" +
                "  id_matkul   INT          AUTO_INCREMENT PRIMARY KEY, " +
                "  nama_matkul VARCHAR(100) NOT NULL UNIQUE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            st.executeUpdate(
                "CREATE TABLE IF NOT EXISTS tabel_tugas (" +
                "  id_tugas   INT           AUTO_INCREMENT PRIMARY KEY, " +
                "  id_user    INT           NOT NULL, " +
                "  id_matkul  INT           NOT NULL, " +
                "  nama_tugas VARCHAR(200)  NOT NULL, " +
                "  deadline   DATE          NOT NULL, " +
                "  prioritas  ENUM('Tinggi','Sedang','Rendah') NOT NULL DEFAULT 'Sedang', " +
                "  status     ENUM('In Progress','Pending','Done','Terlewat') NOT NULL DEFAULT 'Pending', " +
                "  created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP, " +
                "  FOREIGN KEY (id_user)   REFERENCES tabel_users(id_user)   ON DELETE CASCADE, " +
                "  FOREIGN KEY (id_matkul) REFERENCES tabel_matkul(id_matkul) ON DELETE CASCADE" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            try {
                st.executeUpdate(
                    "ALTER TABLE tabel_tugas MODIFY COLUMN status " +
                    "ENUM('In Progress','Pending','Done','Terlewat') NOT NULL DEFAULT 'Pending'"
                );
            } catch (SQLException ignored) {}
        }
    }

    public static void closeQuietly(AutoCloseable... resources) {
        for (AutoCloseable r : resources) {
            if (r != null) {
                try { r.close(); } catch (Exception ignored) {}
            }
        }
    }
}