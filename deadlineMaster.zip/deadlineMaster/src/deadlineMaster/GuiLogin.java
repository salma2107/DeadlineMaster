package deadlineMaster;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class GuiLogin extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final Color BG_APP       = new Color(0xF1F5F9);
    private static final Color BG_CARD      = Color.WHITE;
    private static final Color BLUE_PRIMARY = new Color(0x3B82F6);
    private static final Color BLUE_HOVER   = new Color(0x2563EB);
    private static final Color GREEN_REG    = new Color(0x10B981);
    private static final Color GREEN_HOVER  = new Color(0x059669);
    private static final Color TEXT_DARK    = new Color(0x1E293B);
    private static final Color TEXT_MUTED   = new Color(0x64748B);
    private static final Color BORDER_COLOR = new Color(0xE2E8F0);
    private static final Color RED_ERR      = new Color(0xEF4444);

    private static final int FIELD_W = 290;
    private static final int FIELD_H = 42;
    private static final int BTN_W   = 290;
    private static final int BTN_H   = 44;

    private JPanel     cardPanel;
    private JLabel     lblTitle;
    private JLabel     lblSubtitle;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JPasswordField txtConfirmPass;
    private JLabel     lblConfirmPass;
    private JPanel     rowConfirmPass;
    private RoundButton btnAction;
    private JLabel     lblSwitch;
    private JLabel     lblMessage;

    private boolean isLoginMode = true;
    private final TugasController controller = new TugasController();

    public GuiLogin() {
        super("DeadlineMaster v2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(440, 560);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(BG_APP);
        setLayout(new GridBagLayout());

        buildUI();
        applyLoginMode();

        setVisible(true);
    }

    private void buildUI() {
        cardPanel = new RoundPanel(20, BG_CARD);
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
        cardPanel.setBorder(new EmptyBorder(36, 40, 36, 40));
        cardPanel.setPreferredSize(new Dimension(380, 460));

        JLabel lblLogo = new JLabel("📋", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblTitle = new JLabel("", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_DARK);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        lblSubtitle = new JLabel("", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(TEXT_MUTED);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel formContainer = new JPanel();
        formContainer.setOpaque(false);
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setAlignmentX(Component.CENTER_ALIGNMENT);
        formContainer.setMaximumSize(new Dimension(FIELD_W, Integer.MAX_VALUE));

        JLabel lblUser = makeFieldLabel("Username");
        txtUsername = makeTextField("Masukkan username");

        JLabel lblPass = makeFieldLabel("Password");
        txtPassword = makePasswordField("Masukkan password");
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) handleAction();
            }
        });

        lblConfirmPass = makeFieldLabel("Konfirmasi Password");
        txtConfirmPass = makePasswordField("Ulangi password");

        rowConfirmPass = new JPanel();
        rowConfirmPass.setOpaque(false);
        rowConfirmPass.setLayout(new BoxLayout(rowConfirmPass, BoxLayout.Y_AXIS));
        rowConfirmPass.add(lblConfirmPass);
        rowConfirmPass.add(Box.createVerticalStrut(4));
        rowConfirmPass.add(txtConfirmPass);
        rowConfirmPass.setMaximumSize(new Dimension(FIELD_W, 70));

        formContainer.add(lblUser);
        formContainer.add(Box.createVerticalStrut(4));
        formContainer.add(txtUsername);
        formContainer.add(Box.createVerticalStrut(14));
        formContainer.add(lblPass);
        formContainer.add(Box.createVerticalStrut(4));
        formContainer.add(txtPassword);
        formContainer.add(Box.createVerticalStrut(14));
        formContainer.add(rowConfirmPass);

        lblMessage = new JLabel(" ", SwingConstants.CENTER);
        lblMessage.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblMessage.setForeground(RED_ERR);
        lblMessage.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblMessage.setMaximumSize(new Dimension(FIELD_W, 20));

        btnAction = new RoundButton("", BLUE_PRIMARY, BLUE_HOVER, Color.WHITE);
        btnAction.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAction.setPreferredSize(new Dimension(BTN_W, BTN_H));
        btnAction.setMaximumSize(new Dimension(BTN_W, BTN_H));
        btnAction.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnAction.addActionListener(e -> handleAction());

        lblSwitch = new JLabel("", SwingConstants.CENTER);
        lblSwitch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSwitch.setForeground(BLUE_PRIMARY);
        lblSwitch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblSwitch.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblSwitch.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { toggleMode(); }
            @Override public void mouseEntered(MouseEvent e) { lblSwitch.setForeground(BLUE_HOVER); }
            @Override public void mouseExited(MouseEvent e)  { lblSwitch.setForeground(BLUE_PRIMARY); }
        });

        cardPanel.add(lblLogo);
        cardPanel.add(Box.createVerticalStrut(8));
        cardPanel.add(lblTitle);
        cardPanel.add(Box.createVerticalStrut(4));
        cardPanel.add(lblSubtitle);
        cardPanel.add(Box.createVerticalStrut(24));
        cardPanel.add(formContainer);
        cardPanel.add(Box.createVerticalStrut(6));
        cardPanel.add(lblMessage);
        cardPanel.add(Box.createVerticalStrut(10));
        cardPanel.add(btnAction);
        cardPanel.add(Box.createVerticalStrut(16));
        cardPanel.add(lblSwitch);

        add(cardPanel);
    }

    private void applyLoginMode() {
        lblTitle.setText("Selamat Datang Kembali!");
        lblSubtitle.setText("Masuk ke akun DeadlineMaster Anda");
        btnAction.setLabel("Masuk");
        btnAction.setBgColor(BLUE_PRIMARY, BLUE_HOVER);
        lblSwitch.setText("<html><u>Belum punya akun? Daftar di sini</u></html>");
        rowConfirmPass.setVisible(false);
        clearMessage();
        cardPanel.setPreferredSize(new Dimension(380, 430));
    }

    private void applyRegisterMode() {
        lblTitle.setText("Buat Akun Baru");
        lblSubtitle.setText("Daftar dan mulai kelola tugas Anda");
        btnAction.setLabel("Daftar Sekarang");
        btnAction.setBgColor(GREEN_REG, GREEN_HOVER);
        lblSwitch.setText("<html><u>Sudah punya akun? Masuk di sini</u></html>");
        rowConfirmPass.setVisible(true);
        clearMessage();
        cardPanel.setPreferredSize(new Dimension(380, 500));
    }

    private void toggleMode() {
        isLoginMode = !isLoginMode;
        txtUsername.setText("");
        txtPassword.setText("");
        txtConfirmPass.setText("");
        if (isLoginMode) applyLoginMode();
        else             applyRegisterMode();
        cardPanel.revalidate();
        cardPanel.repaint();
        pack();
        setLocationRelativeTo(null);
    }

    private void handleAction() {
        clearMessage();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            showError("Username dan password tidak boleh kosong.");
            return;
        }
        if (isLoginMode) doLogin(username, password);
        else             doRegister(username, password);
    }

    private void doLogin(String username, String password) {
        btnAction.setEnabled(false);
        SwingWorker<Integer, Void> worker = new SwingWorker<>() {
            @Override protected Integer doInBackground() throws Exception {
                return controller.loginUser(username, password);
            }
            @Override protected void done() {
                try {
                    int userId = get();
                    if (userId > 0) {
                        dispose();
                        new GuiDM(userId, username);
                    } else {
                        showError("Username atau password salah.");
                        btnAction.setEnabled(true);
                    }
                } catch (Exception ex) {
                    showError("Gagal terhubung ke database: " + ex.getMessage());
                    btnAction.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private void doRegister(String username, String password) {
        String confirmPass = new String(txtConfirmPass.getPassword());
        if (!password.equals(confirmPass)) {
            showError("Konfirmasi password tidak cocok."); return;
        }
        if (username.length() < 3) {
            showError("Username minimal 3 karakter."); return;
        }
        if (password.length() < 6) {
            showError("Password minimal 6 karakter."); return;
        }
        btnAction.setEnabled(false);
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override protected Boolean doInBackground() throws Exception {
                return controller.registerUser(username, password);
            }
            @Override protected void done() {
                try {
                    boolean ok = get();
                    if (ok) {
                        showSuccess("Akun berhasil dibuat! Silakan login.");
                        toggleMode();
                        txtUsername.setText(username);
                    } else {
                        showError("Username '" + username + "' sudah digunakan.");
                    }
                } catch (Exception ex) {
                    showError("Error: " + ex.getMessage());
                } finally {
                    btnAction.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private void showError(String msg)   { lblMessage.setForeground(RED_ERR);   lblMessage.setText(msg); }
    private void showSuccess(String msg) { lblMessage.setForeground(GREEN_REG); lblMessage.setText(msg); }
    private void clearMessage()          { lblMessage.setText(" "); }

    private JLabel makeFieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(TEXT_DARK);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JTextField makeTextField(String placeholder) {
        JTextField tf = new JTextField() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getText().isEmpty() && !isFocusOwner()) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setColor(TEXT_MUTED);
                    g2.setFont(getFont().deriveFont(Font.ITALIC));
                    g2.drawString(placeholder, 12, getHeight() / 2 + 5);
                }
            }
        };
        styleInputField(tf);
        return tf;
    }

    private JPasswordField makePasswordField(String placeholder) {
        JPasswordField pf = new JPasswordField() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (getPassword().length == 0 && !isFocusOwner()) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setColor(TEXT_MUTED);
                    g2.setFont(getFont().deriveFont(Font.ITALIC));
                    g2.drawString(placeholder, 12, getHeight() / 2 + 5);
                }
            }
        };
        styleInputField(pf);
        return pf;
    }

    private void styleInputField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setForeground(TEXT_DARK);
        tf.setBackground(Color.WHITE);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
            new EmptyBorder(8, 12, 8, 12)
        ));
        tf.setMaximumSize(new Dimension(FIELD_W, FIELD_H));
        tf.setPreferredSize(new Dimension(FIELD_W, FIELD_H));
        tf.setAlignmentX(Component.LEFT_ALIGNMENT);
        tf.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BLUE_PRIMARY, 2, true),
                    new EmptyBorder(7, 11, 7, 11)
                ));
            }
            @Override public void focusLost(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                    new EmptyBorder(8, 12, 8, 12)
                ));
            }
        });
    }

    static class RoundPanel extends JPanel {
        private static final long serialVersionUID = 1L;
        private final int radius;
        private final Color bg;

        RoundPanel(int radius, Color bg) {
            this.radius = radius;
            this.bg = bg;
            setOpaque(false);
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 15));
            g2.fill(new RoundRectangle2D.Float(2, 4, getWidth() - 4, getHeight() - 2, radius * 2, radius * 2));
            g2.setColor(bg);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), radius * 2, radius * 2));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    static class RoundButton extends JComponent {
        private static final long serialVersionUID = 1L;
        private String label;
        private Color bgColor, bgHover, fgColor;
        private boolean hovered = false;

        RoundButton(String label, Color bg, Color hover, Color fg) {
            this.label   = label;
            this.bgColor = bg;
            this.bgHover = hover;
            this.fgColor = fg;
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setOpaque(false);
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hovered = true;  repaint(); }
                @Override public void mouseExited(MouseEvent e)  { hovered = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) {
                    if (isEnabled()) {
                        for (ActionListener al : listenerList.getListeners(ActionListener.class))
                            al.actionPerformed(new ActionEvent(RoundButton.this, ActionEvent.ACTION_PERFORMED, label));
                    }
                }
            });
        }

        void setLabel(String label) { this.label = label; repaint(); }
        void setBgColor(Color bg, Color hover) { this.bgColor = bg; this.bgHover = hover; repaint(); }
        public void addActionListener(ActionListener l) { listenerList.add(ActionListener.class, l); }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor((!isEnabled()) ? new Color(0xCBD5E1) : (hovered ? bgHover : bgColor));
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
            g2.setColor(fgColor);
            g2.setFont(getFont() != null ? getFont() : new Font("Segoe UI", Font.BOLD, 14));
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth()  - fm.stringWidth(label)) / 2;
            int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            g2.drawString(label, x, y);
            g2.dispose();
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(GuiLogin::new);
    }
}