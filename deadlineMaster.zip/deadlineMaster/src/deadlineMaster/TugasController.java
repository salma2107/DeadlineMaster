package deadlineMaster;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TugasController {

    public static class Tugas {
        public int    idTugas;
        public int    idMatkul;
        public String namaMatkul;
        public String namaTugas;
        public String deadline;
        public String prioritas;
        public String status;

        public Tugas(int idTugas, int idMatkul, String namaMatkul,
                     String namaTugas, String deadline, String prioritas, String status) {
            this.idTugas    = idTugas;
            this.idMatkul   = idMatkul;
            this.namaMatkul = namaMatkul;
            this.namaTugas  = namaTugas;
            this.deadline   = deadline;
            this.prioritas  = prioritas;
            this.status     = status;
        }
    }

    /** Data Transfer Object untuk statistik ringkasan. */
    public static class Statistik {
        public int aktif;
        public int mendesak;
        public int selesai;
        public int terlewat; // Tambahkan variabel ini

        public Statistik(int aktif, int mendesak, int selesai, int terlewat) {
            this.aktif    = aktif;
            this.mendesak = mendesak;
            this.selesai  = selesai;
            this.terlewat = terlewat; // Tambahkan inisialisasi ini
        }
    }

    private void updateStatusTerlewat(Connection conn, int userId) throws SQLException {
        String sql =
            "UPDATE tabel_tugas SET status = 'Terlewat' " +
            "WHERE id_user = ? " +
            "AND status IN ('Pending', 'In Progress') " +
            "AND deadline < CURDATE()";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        }
    }

    public boolean registerUser(String username, String password) throws SQLException {
        String hash = hashPassword(password);
        String sql = "INSERT INTO tabel_users (username, password) VALUES (?, ?)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, hash);
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false;
        }
    }

    public int loginUser(String username, String password) throws SQLException {
        String hash = hashPassword(password);
        String sql = "SELECT id_user FROM tabel_users WHERE username = ? AND password = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, hash);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_user");
                }
            }
        }
        return -1;
    }

    private String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            return password;
        }
    }

    public List<Tugas> dapatkanTugasUser(int userId) throws SQLException {
        List<Tugas> list = new ArrayList<>();
        try (Connection conn = Koneksi.getConnection()) {
            updateStatusTerlewat(conn, userId);
            String sql =
                "SELECT t.id_tugas, t.id_matkul, m.nama_matkul, " +
                "       t.nama_tugas, t.deadline, t.prioritas, t.status " +
                "FROM tabel_tugas t " +
                "JOIN tabel_matkul m ON t.id_matkul = m.id_matkul " +
                "WHERE t.id_user = ? " +
                "ORDER BY t.deadline ASC, t.prioritas DESC";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(new Tugas(
                            rs.getInt("id_tugas"),
                            rs.getInt("id_matkul"),
                            rs.getString("nama_matkul"),
                            rs.getString("nama_tugas"),
                            rs.getString("deadline"),
                            rs.getString("prioritas"),
                            rs.getString("status")
                        ));
                    }
                }
            }
        }
        return list;
    }

    public List<Tugas> cariTugas(int userId, String filterStatus, String keyword,
                                  boolean hanyaMendesak, int filterIdMatkul) throws SQLException {
        List<Tugas> list = new ArrayList<>();
        try (Connection conn = Koneksi.getConnection()) {
            updateStatusTerlewat(conn, userId);
            StringBuilder sql = new StringBuilder(
                "SELECT t.id_tugas, t.id_matkul, m.nama_matkul, " +
                "       t.nama_tugas, t.deadline, t.prioritas, t.status " +
                "FROM tabel_tugas t " +
                "JOIN tabel_matkul m ON t.id_matkul = m.id_matkul " +
                "WHERE t.id_user = ? "
            );

            if (filterStatus != null && !filterStatus.isEmpty()
                    && !filterStatus.equalsIgnoreCase("Semua")) {
                sql.append("AND t.status = ? ");
            }
            if (keyword != null && !keyword.trim().isEmpty()) {
                sql.append("AND (t.nama_tugas LIKE ? OR m.nama_matkul LIKE ?) ");
            }
            if (hanyaMendesak) {
                sql.append("AND t.deadline <= DATE_ADD(CURDATE(), INTERVAL 3 DAY) " +
                           "AND t.status NOT IN ('Done','Terlewat') ");
            }
            if (filterIdMatkul > 0) {
                sql.append("AND t.id_matkul = ? ");
            }
            sql.append("ORDER BY t.deadline ASC");

            try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
                int idx = 1;
                ps.setInt(idx++, userId);
                if (filterStatus != null && !filterStatus.isEmpty()
                        && !filterStatus.equalsIgnoreCase("Semua")) {
                    ps.setString(idx++, filterStatus);
                }
                if (keyword != null && !keyword.trim().isEmpty()) {
                    String like = "%" + keyword.trim() + "%";
                    ps.setString(idx++, like);
                    ps.setString(idx++, like);
                }
                if (filterIdMatkul > 0) {
                    ps.setInt(idx++, filterIdMatkul);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(new Tugas(
                            rs.getInt("id_tugas"),
                            rs.getInt("id_matkul"),
                            rs.getString("nama_matkul"),
                            rs.getString("nama_tugas"),
                            rs.getString("deadline"),
                            rs.getString("prioritas"),
                            rs.getString("status")
                        ));
                    }
                }
            }
        }
        return list;
    }

    public void tambahTugas(int userId, int matkulId, String nama,
                             String deadline, String prioritas) throws SQLException {
        String sql = "INSERT INTO tabel_tugas (id_user, id_matkul, nama_tugas, deadline, prioritas, status) " +
                     "VALUES (?, ?, ?, ?, ?, 'Pending')";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, matkulId);
            ps.setString(3, nama.trim());
            ps.setString(4, deadline);
            ps.setString(5, prioritas);
            ps.executeUpdate();
        }
    }

    public void ubahStatusTugas(int idTugas, String status) throws SQLException {
        String sql = "UPDATE tabel_tugas SET status = ? WHERE id_tugas = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, idTugas);
            ps.executeUpdate();
        }
    }

    public void updateTugas(int idTugas, int matkulId, String nama,
                             String deadline, String prioritas, String status) throws SQLException {
        String sql = "UPDATE tabel_tugas SET id_matkul=?, nama_tugas=?, deadline=?, " +
                     "prioritas=?, status=? WHERE id_tugas=?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, matkulId);
            ps.setString(2, nama.trim());
            ps.setString(3, deadline);
            ps.setString(4, prioritas);
            ps.setString(5, status);
            ps.setInt(6, idTugas);
            ps.executeUpdate();
        }
    }

    public void hapusTugas(int idTugas) throws SQLException {
        String sql = "DELETE FROM tabel_tugas WHERE id_tugas = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idTugas);
            ps.executeUpdate();
        }
    }

    public Statistik hitungStatistikUser(int userId) throws SQLException {
        String sql =
            "SELECT " +
            "  SUM(CASE WHEN status IN ('In Progress','Pending') THEN 1 ELSE 0 END) AS aktif, " +
            "  SUM(CASE WHEN deadline <= DATE_ADD(CURDATE(), INTERVAL 3 DAY) " +
            "           AND status NOT IN ('Done', 'Terlewat') THEN 1 ELSE 0 END) AS mendesak, " +
            "  SUM(CASE WHEN status = 'Done' THEN 1 ELSE 0 END) AS selesai, " +
            "  SUM(CASE WHEN status = 'Terlewat' THEN 1 ELSE 0 END) AS terlewat " + // Hitung terlewat
            "FROM tabel_tugas WHERE id_user = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Statistik(
                        rs.getInt("aktif"),
                        rs.getInt("mendesak"),
                        rs.getInt("selesai"),
                        rs.getInt("terlewat") // Masukkan ke constructor
                    );
                }
            }
        }
        return new Statistik(0, 0, 0, 0);
    }

    public Map<Integer, String> dapatkanSemuaMatkul() throws SQLException {
        Map<Integer, String> map = new HashMap<>();
        String sql = "SELECT id_matkul, nama_matkul FROM tabel_matkul ORDER BY nama_matkul";
        try (Connection conn = Koneksi.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                map.put(rs.getInt("id_matkul"), rs.getString("nama_matkul"));
            }
        }
        return map;
    }

    public int getIdMatkul(String namaMatkul) throws SQLException {
        String sql = "SELECT id_matkul FROM tabel_matkul WHERE nama_matkul = ?";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, namaMatkul);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_matkul");
                }
            }
        }
        return -1;
    }

    public List<Tugas> dapatkanTugasMenudesak(int userId) throws SQLException {
        List<Tugas> list = new ArrayList<>();
        String sql =
            "SELECT t.id_tugas, t.id_matkul, m.nama_matkul, " +
            "       t.nama_tugas, t.deadline, t.prioritas, t.status " +
            "FROM tabel_tugas t " +
            "JOIN tabel_matkul m ON t.id_matkul = m.id_matkul " +
            "WHERE t.id_user = ? " +
            "AND t.status NOT IN ('Done','Terlewat') " +
            "AND t.deadline = DATE_ADD(CURDATE(), INTERVAL 1 DAY)";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Tugas(
                        rs.getInt("id_tugas"), rs.getInt("id_matkul"),
                        rs.getString("nama_matkul"), rs.getString("nama_tugas"),
                        rs.getString("deadline"), rs.getString("prioritas"),
                        rs.getString("status")
                    ));
                }
            }
        }
        return list;
    }

    /**
     * Mengambil semua tugas dari seluruh pengguna yang tenggat waktunya besok (H-1)
     * dan statusnya belum selesai (Pending / In Progress).
     */
    public List<Tugas> dapatkanSemuaTugasMenudesak() throws SQLException {
        List<Tugas> list = new ArrayList<>();
        String sql =
            "SELECT t.id_tugas, t.id_matkul, m.nama_matkul, " +
            "       t.nama_tugas, t.deadline, t.prioritas, t.status " +
            "FROM tabel_tugas t " +
            "JOIN tabel_matkul m ON t.id_matkul = m.id_matkul " +
            "WHERE t.deadline = DATE_ADD(CURDATE(), INTERVAL 1 DAY) " +
            "AND t.status IN ('Pending', 'In Progress') " +
            "ORDER BY t.prioritas DESC";
        try (Connection conn = Koneksi.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Tugas(
                    rs.getInt("id_tugas"),
                    rs.getInt("id_matkul"),
                    rs.getString("nama_matkul"),
                    rs.getString("nama_tugas"),
                    rs.getString("deadline"),
                    rs.getString("prioritas"),
                    rs.getString("status")
                ));
            }
        }
        return list;
    }
}